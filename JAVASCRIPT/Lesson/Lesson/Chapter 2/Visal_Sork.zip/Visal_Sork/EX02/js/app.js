

let visible = (element, id) => {
    // your code here
}

let btnShow = // your code here;
let btnHide = // your code here;

btnHide.addEventListener('click', hideImage);
btnShow.addEventListener('click', showImage);